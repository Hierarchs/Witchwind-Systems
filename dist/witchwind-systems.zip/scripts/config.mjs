export const MODULE_ID = "witchwind-systems";
export const PATH = `modules/${MODULE_ID}`;

/** Localization root for every string the module shows. */
export const L = "WITCHWIND_SYSTEMS";

/** The four sections, in the order of the tabs along the bottom of the window. */
export const SECTION_IDS = ["quests", "journal", "maps", "factions"];

export const SECTION_ICONS = {
  quests: "fa-solid fa-scroll-old",
  journal: "fa-solid fa-feather-pointed",
  maps: "fa-solid fa-map",
  factions: "fa-solid fa-chess-rook"
};

/* -------------------------------------------- */
/*  Quests                                      */
/* -------------------------------------------- */

/** Quest groups, in the order they're listed. */
export const QUEST_KINDS = ["main", "side", "faction", "misc"];

export const QUEST_STATUSES = ["active", "completed", "failed"];

/* -------------------------------------------- */
/*  Journal                                     */
/* -------------------------------------------- */

export const NOTE_KINDS = ["general", "people", "places", "lore", "clues"];

export const NOTE_ICONS = {
  general: "fa-solid fa-feather",
  people: "fa-solid fa-user",
  places: "fa-solid fa-signs-post",
  lore: "fa-solid fa-book-sparkles",
  clues: "fa-solid fa-magnifying-glass"
};

/* -------------------------------------------- */
/*  Maps                                        */
/* -------------------------------------------- */

/** Marker icons offered when placing a pin (Font Awesome Pro, which Foundry ships). */
export const PIN_ICONS = {
  location: "fa-location-dot",
  city: "fa-city",
  village: "fa-house-chimney",
  castle: "fa-castle",
  tower: "fa-chess-rook",
  dungeon: "fa-dungeon",
  camp: "fa-campfire",
  tavern: "fa-mug-hot",
  temple: "fa-place-of-worship",
  shop: "fa-sack-dollar",
  port: "fa-anchor",
  forest: "fa-tree",
  mountain: "fa-mountain",
  ruins: "fa-monument",
  danger: "fa-skull",
  treasure: "fa-treasure-chest",
  quest: "fa-star",
  person: "fa-person",
  note: "fa-feather",
  flag: "fa-flag"
};

/** Marker colors: Witchwind's gold and its rarity colors. */
export const PIN_COLORS = {
  gold: "#c9a45c",
  ivory: "#efe3c8",
  red: "#c4473a",
  orange: "#c97d24",
  green: "#4f8f49",
  blue: "#3f7fc4",
  purple: "#8a62c0"
};

/* -------------------------------------------- */
/*  Factions                                    */
/* -------------------------------------------- */

/** Ranks a new faction starts with, lowest first. */
export const DEFAULT_RANKS = ["Initiate", "Member", "Veteran", "Officer", "Master"];

/** Standing runs from -100 to 100; each tier starts at its threshold. */
export const STANDING_TIERS = [
  { id: "hated", min: -100 },
  { id: "hostile", min: -75 },
  { id: "unfriendly", min: -40 },
  { id: "neutral", min: -10 },
  { id: "friendly", min: 10 },
  { id: "trusted", min: 40 },
  { id: "revered", min: 75 }
];

export function standingTier(value) {
  let tier = STANDING_TIERS[0];
  for ( const t of STANDING_TIERS ) if ( value >= t.min ) tier = t;
  return tier.id;
}
